package in.bapu.distancemeter

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.widget.Toast
import com.google.ar.core.*
import java.util.Locale
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: ArRenderer
    private lateinit var result: TextView
    private lateinit var hint: TextView
    private var mode = Mode.TWO_POINTS
    private var firstPoint: FloatArray? = null
    private var session: Session? = null
    private var installRequested = false
    private var resumed = false

    enum class Mode { OBJECT, TWO_POINTS }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            renderer = ArRenderer { frame, x, y -> handleTap(frame, x, y) }
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    val tx = event.x; val ty = event.y
                    queueEvent { renderer.requestTap(tx, ty) }
                    true
                } else true
            }
        }
        root.addView(glView, LinearLayout.LayoutParams(-1, 0, 1f))
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 14); setBackgroundColor(Color.rgb(20,25,35)) }
        panel.addView(TextView(this).apply { text = "BAPU DISTANCE METER"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        hint = TextView(this).apply { text = "पृष्ठभागावर टॅप करा. दोन बिंदू निवडा."; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(4,8,4,8) }
        panel.addView(hint)
        result = TextView(this).apply { text = "अंतर: --"; textSize = 23f; setTextColor(Color.rgb(90,220,160)); gravity = Gravity.CENTER; setPadding(4,6,4,10) }
        panel.addView(result)
        val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER }
        buttons.addView(Button(this).apply { text = "वस्तूपर्यंत"; setOnClickListener { mode = Mode.OBJECT; firstPoint = null; updateHint() } })
        buttons.addView(Button(this).apply { text = "दोन बिंदू"; setOnClickListener { mode = Mode.TWO_POINTS; firstPoint = null; updateHint() } })
        buttons.addView(Button(this).apply { text = "रीसेट"; setOnClickListener { firstPoint = null; result.text = "अंतर: --"; updateHint() } })
        panel.addView(buttons)
        root.addView(panel)
        setContentView(root)
    }

    private fun updateHint() {
        hint.text = if (mode == Mode.OBJECT) "वस्तूच्या पृष्ठभागावर टॅप करा." else "पहिला बिंदू निवडा; नंतर दुसरा बिंदू निवडा."
    }

    private fun handleTap(frame: Frame, x: Float, y: Float) {
        try {
            val hit = frame.hitTest(x, y).firstOrNull { h ->
                val t = h.trackable
                (t is Plane && t.isPoseInPolygon(h.hitPose)) || t is Point || t is DepthPoint
            } ?: run { runOnUiThread { hint.text = "पृष्ठभाग सापडला नाही. हळू हलवा आणि पुन्हा टॅप करा." }; return }
            val p = hit.hitPose.translation
            if (mode == Mode.OBJECT) {
                val d = distance(frame.camera.pose.translation, p)
                runOnUiThread { result.text = "अंतर: ${formatFeet(d)}"; hint.text = "वस्तूपर्यंतचे अंतर मोजले." }
            } else {
                val first = firstPoint
                if (first == null) {
                    firstPoint = p.copyOf()
                    runOnUiThread { hint.text = "पहिला बिंदू नोंदवला. आता दुसऱ्या बिंदूवर टॅप करा."; result.text = "दुसरा बिंदू निवडा" }
                } else {
                    val d = distance(first, p)
                    firstPoint = null
                    runOnUiThread { result.text = "अंतर: ${formatFeet(d)}"; hint.text = "मोजमाप पूर्ण." }
                }
            }
        } catch (_: Exception) {
            runOnUiThread { hint.text = "मोजमाप झाले नाही. कॅमेरा हळू हलवून पुन्हा प्रयत्न करा." }
        }
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        val x=a[0]-b[0]; val y=a[1]-b[1]; val z=a[2]-b[2]
        return sqrt(x*x+y*y+z*z)
    }
    private fun formatFeet(meters: Float): String {
        val totalInches = meters * 39.3700787f
        val feet = totalInches.toInt() / 12
        val inches = totalInches - feet * 12
        return String.format(Locale.US, "%d ft %.1f in (%.2f m)", feet, inches, meters)
    }

    override fun onResume() {
        super.onResume()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10); return
        }
        try {
            if (session == null) {
                if (!ArCoreApk.getInstance().checkAvailability(this).isSupported) { toast("या डिव्हाइसवर ARCore उपलब्ध नाही."); return }
                when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                    ArCoreApk.InstallStatus.INSTALL_REQUESTED -> { installRequested = true; return }
                    ArCoreApk.InstallStatus.INSTALLED -> {}
                }
                session = Session(this)
                val config = Config(session)
                config.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                config.depthMode = if (session!!.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) Config.DepthMode.AUTOMATIC else Config.DepthMode.DISABLED
                session!!.configure(config)
            }
            session?.resume()
            glView.onResume()
            resumed = true
            renderer.setSession(session)
        } catch (e: Exception) { toast("AR सुरू झाले नाही: ${e.localizedMessage ?: "त्रुटी"}") }
    }

    override fun onPause() {
        super.onPause()
        if (resumed) { glView.onPause(); session?.pause(); resumed = false }
    }
    override fun onDestroy() { session?.close(); session = null; super.onDestroy() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) onResume()
        else toast("कॅमेरा परवानगी आवश्यक आहे.")
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
