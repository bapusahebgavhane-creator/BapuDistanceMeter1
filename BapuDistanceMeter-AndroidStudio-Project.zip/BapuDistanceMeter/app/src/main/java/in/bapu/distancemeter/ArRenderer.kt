package in.bapu.distancemeter

import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.graphics.SurfaceTexture
import com.google.ar.core.Frame
import com.google.ar.core.Session
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ArRenderer(private val onTap: (Frame, Float, Float) -> Unit) : GLSurfaceView.Renderer {
    @Volatile private var session: Session? = null
    @Volatile private var tapX = -1f
    @Volatile private var tapY = -1f
    private var textureId = -1
    private var surfaceTexture: SurfaceTexture? = null
    private var program = 0
    private var posLoc = 0
    private var uvLoc = 0
    private var samplerLoc = 0
    private val vertices = buffer(floatArrayOf(-1f,-1f, 1f,-1f, -1f,1f, 1f,1f))
    private val uv = buffer(floatArrayOf(0f,1f, 1f,1f, 0f,0f, 1f,0f))

    fun setSession(value: Session?) { session = value }
    fun requestTap(x: Float, y: Float) { tapX = x; tapY = y }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        textureId = IntArray(1).also { GLES20.glGenTextures(1,it,0) }[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        surfaceTexture = SurfaceTexture(textureId)
        program = linkProgram(VS, FS)
        posLoc = GLES20.glGetAttribLocation(program, "aPosition")
        uvLoc = GLES20.glGetAttribLocation(program, "aTexCoord")
        samplerLoc = GLES20.glGetUniformLocation(program, "sTexture")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { GLES20.glViewport(0,0,width,height) }

    override fun onDrawFrame(gl: GL10?) {
        val s = session ?: run { GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); return }
        try {
            s.setCameraTextureName(textureId)
            val frame = s.update()
            surfaceTexture?.updateTexImage()
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            GLES20.glUseProgram(program)
            vertices.position(0); GLES20.glVertexAttribPointer(posLoc,2,GLES20.GL_FLOAT,false,0,vertices); GLES20.glEnableVertexAttribArray(posLoc)
            uv.position(0); GLES20.glVertexAttribPointer(uvLoc,2,GLES20.GL_FLOAT,false,0,uv); GLES20.glEnableVertexAttribArray(uvLoc)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,textureId)
            GLES20.glUniform1i(samplerLoc,0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
            val x=tapX; val y=tapY
            if (x >= 0f) { tapX=-1f; onTap(frame,x,y) }
        } catch (_: Exception) { }
    }

    private fun buffer(a: FloatArray): FloatBuffer = ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }
    private fun shader(type: Int, source: String): Int = GLES20.glCreateShader(type).also { GLES20.glShaderSource(it,source); GLES20.glCompileShader(it) }
    private fun linkProgram(vs: String, fs: String): Int {
        val v=shader(GLES20.GL_VERTEX_SHADER,vs); val f=shader(GLES20.GL_FRAGMENT_SHADER,fs)
        return GLES20.glCreateProgram().also { GLES20.glAttachShader(it,v); GLES20.glAttachShader(it,f); GLES20.glLinkProgram(it) }
    }
    companion object {
        private const val VS = "attribute vec4 aPosition; attribute vec2 aTexCoord; varying vec2 vTexCoord; void main(){ gl_Position=aPosition; vTexCoord=aTexCoord; }"
        private const val FS = "#extension GL_OES_EGL_image_external : require\nprecision mediump float; uniform samplerExternalOES sTexture; varying vec2 vTexCoord; void main(){ gl_FragColor=texture2D(sTexture,vTexCoord); }"
    }
}
