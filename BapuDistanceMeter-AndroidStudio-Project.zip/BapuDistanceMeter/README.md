# Bapu Distance Meter — Android Studio project

This ZIP contains Android source code, not a precompiled APK.

## Build an APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open the `BapuDistanceMeter` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect the OnePlus Nord CE5 with USB debugging enabled, then Run; or choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Features
- Object mode: tap a detected surface/depth point to estimate camera-to-point distance.
- Two-point mode: tap two detected points to calculate 3D distance.
- Results shown in feet and inches, with metres in brackets.

## Important
- Requires Google Play Services for AR (ARCore), camera permission, and an ARCore-supported device.
- Move the phone slowly over a textured, well-lit surface.
- Object mode measures to the selected surface/depth point; it does not infer the distance to an arbitrary object without a usable AR hit.
- This is an initial prototype, not a surveying instrument. Compare readings with a physical tape measure before relying on them.
- Camera preview orientation and tap alignment may need device-specific testing and adjustment.
